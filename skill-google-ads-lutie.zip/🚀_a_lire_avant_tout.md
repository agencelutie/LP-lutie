# Skill Google Ads pour Claude — Guide d'utilisation

Ce skill transforme Claude en expert Google Ads : analyse de campagnes, audit de structure, recommandations budgétaires, rédaction d'annonces, détection d'anomalies...

---

## Installation en 3 étapes

**1. Télécharger le skill**
Téléchargez le fichier `ads-google-lutie.skill` depuis [skill.lutie.fr](https://skill.lutie.fr).

**2. Importer dans Claude Code**
Ouvrez votre terminal et exécutez :
```
claude skill install ads-google-lutie.skill
```
Le skill est maintenant disponible dans toutes vos sessions Claude Code.

**3. Utiliser le skill**
Dans une conversation Claude Code, tapez simplement :
```
/ads-google
```
Claude charge automatiquement le contexte expert et vous pouvez commencer à travailler sur vos campagnes.

---

## Aller plus loin avec le MCP Google Ads officiel

Pour connecter Claude directement à votre compte Google Ads (données en temps réel, rapports automatiques, actions directes), installez le MCP officiel Google Ads :

👉 **[github.com/googleads/google-ads-mcp](https://github.com/googleads/google-ads-mcp)**

Le MCP vous permet d'interroger vos vraies campagnes depuis Claude, sans copier-coller de données.

---

## Ce que vous pouvez faire avec ce skill

- Auditer la structure de vos campagnes (Search, Performance Max, Shopping)
- Analyser vos mots-clés, correspondances et scores de qualité
- Identifier les pertes de budget inutiles
- Rédiger et optimiser vos annonces responsives
- Interpréter vos rapports de performances
- Préparer vos recommandations stratégiques

---

## Une question ? Un audit humain ?

Ce skill a été conçu par **[Lutie](https://lutie.fr)**, agence spécialisée Google Ads.

Si vous avez besoin d'un regard humain sur vos campagnes, d'un audit complet ou d'un accompagnement sur la durée, contactez-nous avec plaisir :

🌐 [lutie.fr](https://lutie.fr)

---

*Skill créé par Lutie — Agence Google Ads*
